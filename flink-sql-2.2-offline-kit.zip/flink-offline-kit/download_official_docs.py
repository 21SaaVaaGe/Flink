"""Mirror the official English Flink 2.2 user guide for offline use."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlsplit, unquote
from urllib.request import Request, urlopen
import json
import posixpath
import re
import xml.etree.ElementTree as ET

ROOT = "https://nightlies.apache.org/flink/flink-docs-release-2.2/"
SITEMAP = urljoin(ROOT, "en/sitemap.xml")
OUT = Path(__file__).parent / "official-docs-2.2"
HEADERS = {"User-Agent": "FlinkOfflineDocsMirror/1.0 (user-requested archival copy)"}
ASSET_EXT = {".css", ".js", ".svg", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".woff", ".woff2", ".ttf", ".ico", ".pdf", ".json", ".xml"}
PAGE_PATHS = set()


def fetch(url):
    error = None
    for _ in range(3):
        try:
            with urlopen(Request(url, headers=HEADERS), timeout=40) as response:
                return response.read()
        except Exception as exc:
            error = exc
    raise error


def local_path(url):
    parsed = urlsplit(url)
    if parsed.netloc != "nightlies.apache.org":
        return None
    if parsed.path == "/flink/flink-docs-release-2.2":
        relative = "index.html"
    elif parsed.path.startswith("/flink/flink-docs-release-2.2/"):
        relative = parsed.path.removeprefix("/flink/flink-docs-release-2.2/")
    elif parsed.path.startswith("/flink/") and not parsed.path.startswith("/flink/flink-docs-"):
        relative = "shared/" + parsed.path.removeprefix("/flink/")
    else:
        return None
    relative = unquote(relative).lstrip("/\\")
    if not relative or relative.endswith("/"):
        relative += "index.html"
    elif not Path(relative).suffix:
        relative += "/index.html"
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        return None
    return path


def canonical(url):
    parsed = urlsplit(urljoin(ROOT, url))
    return parsed._replace(query="", fragment="").geturl()


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = set()

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in {"href", "src"} and value:
                self.urls.add(value)


def rewrite_html(raw, page_url):
    text = raw.decode("utf-8", errors="replace")
    current = local_path(page_url)
    links = Links()
    links.feed(text)
    assets = set()
    for link in links.urls:
        absolute = urljoin(page_url, link)
        target = local_path(absolute)
        if target and target.suffix.lower() in ASSET_EXT:
            assets.add(canonical(absolute))

    pattern = re.compile(r'\b(href|src)=([\"\'])(.*?)(\2)', re.DOTALL)

    def rewrite(match):
        attr, quote, value = match.group(1), match.group(2), match.group(3)
        normalized = value.strip()
        absolute = urljoin(page_url, normalized)
        target = local_path(absolute)
        if not target:
            if normalized.startswith("//"):
                compact_url = re.sub(r"\s+", "", normalized)
                return f'{attr}={quote}https:{compact_url}{quote}'
            if normalized.startswith("/"):
                return f'{attr}={quote}{absolute}{quote}'
            return match.group(0)
        if target.suffix == ".html" and target not in PAGE_PATHS:
            return f'{attr}={quote}{absolute}{quote}'
        rel = posixpath.relpath(target.as_posix(), start=current.parent.as_posix())
        fragment = urlsplit(absolute).fragment
        return f'{attr}={quote}{rel}{("#" + fragment) if fragment else ""}{quote}'

    return pattern.sub(rewrite, text).encode("utf-8"), assets


def save(url, raw, rewrite=True):
    path = local_path(url)
    if path is None:
        return set()
    assets = set()
    if rewrite and path.suffix == ".html":
        raw, assets = rewrite_html(raw, url)
    elif path.suffix == ".css":
        css = raw.decode("utf-8", errors="replace")
        found = set()
        for match in re.finditer(r'url\(\s*[\"\']?([^\)\"\']+)', css):
            absolute = urljoin(url, match.group(1).strip())
            if local_path(absolute):
                found.add(canonical(absolute))
        assets = found
    destination = OUT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    return assets


def main():
    xml = ET.fromstring(fetch(SITEMAP))
    namespace = {"s": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    pages = sorted({canonical(node.text) for node in xml.findall("s:url/s:loc", namespace) if node.text})
    PAGE_PATHS.update(local_path(url) for url in pages)
    assets = set()
    failures = []

    def download_page(url):
        raw = fetch(url)
        return url, raw

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(download_page, url): url for url in pages}
        for future in as_completed(futures):
            try:
                url, raw = future.result()
                assets.update(save(url, raw))
            except Exception as exc:
                failures.append({"url": futures[future], "error": str(exc)})

    pending = assets
    seen = set()
    while pending:
        current = pending - seen
        if not current:
            break
        seen.update(current)
        pending = set()
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = {pool.submit(download_page, url): url for url in current}
            for future in as_completed(futures):
                try:
                    url, raw = future.result()
                    pending.update(save(url, raw, rewrite=False))
                except Exception as exc:
                    failures.append({"url": futures[future], "error": str(exc)})

    manifest = {"source": ROOT, "sitemap": SITEMAP, "pages_expected": len(pages), "pages_downloaded": len(list(OUT.rglob("index.html"))), "assets_seen": len(seen), "failures": failures}
    (OUT / "mirror-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
