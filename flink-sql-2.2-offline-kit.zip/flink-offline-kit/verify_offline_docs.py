"""Report broken local HTML links in the downloaded Flink guide."""

from collections import Counter
from pathlib import Path
from urllib.parse import unquote, urlsplit
import json
import os
import re

ROOT = Path(__file__).parent / "official-docs-2.2"


def main():
    broken = Counter()
    checked = 0
    candidates = Counter()
    for page in ROOT.rglob("*.html"):
        html = page.read_text(encoding="utf-8", errors="replace")
        for raw in re.findall(r'\b(?:href|src)="([^"]+)"', html):
            parsed = urlsplit(raw)
            if parsed.scheme or parsed.netloc or raw.startswith(("#", "data:", "javascript:", "mailto:")):
                continue
            target = Path(os.path.normpath(page.parent / unquote(parsed.path)))
            if not target.is_relative_to(ROOT):
                broken[str(target)] += 1
                continue
            checked += 1
            candidates[target] += 1
    for target, count in candidates.items():
        if target.is_dir():
            target /= "index.html"
        if not target.is_file():
            broken[str(target.relative_to(ROOT))] += count
    report = {"html_pages": len(list(ROOT.rglob("*.html"))), "local_links_checked": checked, "missing_unique": len(broken), "missing": broken.most_common(50)}
    (ROOT / "link-check.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    if broken:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
