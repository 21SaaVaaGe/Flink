# Офлайн-комплект Apache Flink 2.2 SQL и мониторинга

## Открытие

Откройте `START_HERE.html` в браузере без интернета. Зеркало `official-docs-2.2/` содержит англоязычную официальную документацию Apache Flink 2.2: все страницы из её английской карты сайта, включая Table API & SQL, SQL Client/Gateway, коннекторы, форматы, развёртывание, состояние и мониторинг. Для поиска по всем страницам откройте локальный главной странице встроенный поиск; если поиск требует недоступного в `file://` JavaScript, используйте поиск по файлам в проводнике/редакторе.

Основные входы:

- [Table API & SQL](official-docs-2.2/docs/dev/table/overview/index.html)
- [Синтаксис SQL](official-docs-2.2/docs/dev/table/sql/overview/index.html)
- [Функции](official-docs-2.2/docs/dev/table/functions/overview/index.html)
- [Типы данных](official-docs-2.2/docs/dev/table/types/index.html)
- [Kafka SQL connector](official-docs-2.2/docs/connectors/table/kafka/index.html)
- [JDBC SQL connector](official-docs-2.2/docs/connectors/table/jdbc/index.html)
- [Все Table/SQL connector](official-docs-2.2/docs/connectors/table/overview/index.html)
- [Метрики Flink](official-docs-2.2/docs/ops/metrics/index.html)
- [Backpressure](official-docs-2.2/docs/ops/monitoring/back_pressure/index.html)
- [Checkpoint monitoring](official-docs-2.2/docs/ops/monitoring/checkpoint_monitoring/index.html)
- [Metric reporters](official-docs-2.2/docs/deployment/metric_reporters/index.html)

## Мониторинг

В `monitoring/` находятся шаблоны конфигурации Prometheus reporter, scrape targets, алертов, обзорного Grafana dashboard и русская инструкция подключения. Имена экспортированных метрик и адреса targets необходимо сверить с работающим кластером. Для Kafka lag и MSSQL Writer потребуется существующий exporter или инструментирование Writer; шаблон не добавляет эти сервисы автоматически.

## Источник и ограничения

Страницы скачаны с официального `https://nightlies.apache.org/flink/flink-docs-release-2.2/` по английской карте сайта. Список загрузок и ошибок находится в `official-docs-2.2/mirror-manifest.json`. Скрипт `download_official_docs.py` позволяет обновить комплект на машине с интернетом. Внешние ссылки на другие сайты, Java API, GitHub и примеры загрузки JAR остаются внешними: они не являются частью этого зеркала. Сам комплект не включает Flink binaries, connector JAR, Prometheus или Grafana.

Перед использованием в production сверяйте документацию с **фактически установленными** версиями Flink и коннекторов. Документация описывает возможности продукта; она не подтверждает, что конкретная опция доступна в вашем offline classpath.
