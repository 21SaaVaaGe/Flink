# Заготовки мониторинга Flink SQL 2.2

Это шаблоны для существующего кластера, а не готовая конфигурация production. Адреса и пороги требуется привязать к вашей инфраструктуре и SLO.

## Подключение

1. Добавьте параметры из `flink-config.yaml.example` в действующую конфигурацию Flink и перезапустите компоненты по вашей процедуре. Официальный Prometheus reporter входит в документацию Flink 2.2; проверьте доступность `http://<jobmanager>:9249/metrics` и каждого TaskManager.
2. Скопируйте `prometheus.yml.example` и `alerts.yml.example` в конфигурацию Prometheus, замените адреса. Проверьте конфигурацию `promtool check config` и `promtool check rules`, если `promtool` есть в offline-комплекте.
3. В интерфейсе Prometheus выполните `up{job=~"flink-.*"}`. Убедитесь, что все нужные targets равны 1.
4. Откройте `/metrics` и проверьте фактические имена рядов `numberOfFailedCheckpoints` и `backPressuredTimeMsPerSecond`. Сопоставьте их с выражениями в правилах. Если серия отсутствует, не включайте зависимый от неё алерт до корректировки.
5. Импортируйте `grafana-flink-overview.json` в Grafana и выберите ваш Prometheus datasource.
6. Если у вас уже есть Kafka exporter и MSSQL Writer с метриками, адаптируйте `pipeline-alerts.optional.yml.example` к реальным именам рядов и SLO; затем добавьте файл в `rule_files`. В шаблоне предполагаются `kafka_consumergroup_lag`, `mssql_writer_dlq_total` и histogram `mssql_writer_sql_commit_duration_seconds_bucket`. Без таких метрик правила не дадут полезного сигнала.

## Что смотреть для медленного SQL job

- Kafka lag по consumer group и партициям. Источник метрики зависит от выбранного Kafka exporter; не угадывайте имя серии.
- `numRecordsInPerSecond` и `numRecordsOutPerSecond` по каждой задаче, а также `busyTimeMsPerSecond`, `idleTimeMsPerSecond`, `backPressuredTimeMsPerSecond`.
- Успешность, длительность, размер и возраст последнего checkpoint.
- Время от публикации входного события до SQL commit: эту метрику должен измерять Writer или отдельный контрольный поток; внутренние метрики Flink её не заменяют.
- Для Writer: число записанных, повторных и ошибочных событий; SQL batch latency, retries, deadlocks и пул соединений. Эти ряды требуют инструментирования вашего Writer.

## Минимальный разбор инцидента

Если Kafka lag растёт, сначала проверьте, поступают ли данные в source и какой оператор первым стал `busy` или `backpressured`. Высокий backpressure на source может означать медленный downstream. Затем проверьте checkpoint и только после этого изменяйте parallelism или Kafka fetch-настройки. Если Kafka → Blackhole быстр, а полный путь медленен, измерьте sink и MSSQL отдельно.

Источники: `official-docs-2.2/docs/deployment/metric_reporters/index.html`, `official-docs-2.2/docs/ops/monitoring/back_pressure/index.html`, `official-docs-2.2/docs/ops/monitoring/checkpoint_monitoring/index.html`, `official-docs-2.2/docs/ops/metrics/index.html`.
