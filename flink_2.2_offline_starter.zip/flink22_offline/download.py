from pathlib import Path
from urllib.request import urlopen
import hashlib, json
root=Path(__file__).parent
artifacts=[
('org.apache.flink','flink-sql-connector-kafka','5.0.0-2.2'),
('org.apache.flink','flink-connector-jdbc-core','4.1.0-2.2'),
('org.apache.flink','flink-connector-jdbc-sqlserver','4.1.0-2.2'),
('org.apache.flink','flink-connector-jdbc-postgres','4.1.0-2.2'),
('org.apache.flink','flink-connector-jdbc-mysql','4.1.0-2.2'),
('com.microsoft.sqlserver','mssql-jdbc','12.10.2.jre11'),
('org.postgresql','postgresql','42.7.7'),
('com.mysql','mysql-connector-j','9.4.0'),
]
base='https://repo.maven.apache.org/maven2/'
out=root/'jars';out.mkdir(exist_ok=True)
manifest={}
for group,artifact,version in artifacts:
 name=f'{artifact}-{version}.jar';url=base+group.replace('.','/')+f'/{artifact}/{version}/{name}'
 print('Downloading',name,flush=True)
 try:
  data=urlopen(url,timeout=90).read()
  if data[:2]!=b'PK':raise ValueError('not a jar')
  (out/name).write_bytes(data)
  manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'source':url}
 except Exception as e:print('FAILED:',name,e);raise
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('DONE')
