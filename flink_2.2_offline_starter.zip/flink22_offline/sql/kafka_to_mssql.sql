-- Replace Kafka bootstrap server, topic and SQL Server credentials.
CREATE TABLE kafka_events (
  id BIGINT,
  payload STRING
) WITH (
  'connector' = 'kafka',
  'topic' = 'events',
  'properties.bootstrap.servers' = 'kafka:9092',
  'properties.group.id' = 'flink22-example',
  'scan.startup.mode' = 'earliest-offset',
  'format' = 'json'
);

CREATE TABLE mssql_events (
  id BIGINT,
  payload STRING,
  PRIMARY KEY (id) NOT ENFORCED
) WITH (
  'connector' = 'jdbc',
  'url' = 'jdbc:sqlserver://mssql:1433;databaseName=streaming;encrypt=true;trustServerCertificate=true',
  'table-name' = 'dbo.events',
  'username' = 'sa',
  'password' = 'REPLACE_ME'
);

INSERT INTO mssql_events SELECT id, payload FROM kafka_events;
