# Apache Flink 2.2 offline preparation

This archive contains a downloader, Docker Compose and a SQL example. **It does not contain JAR binaries** because Maven Central is unreachable from the packaging environment.

## On an internet-connected machine

1. Run `python download.py` (Python 3.9+).
2. Inspect `jars/` and `manifest.json`. The script fails on unavailable artifacts.
3. Run `docker compose build` and `docker compose up -d` to test.
4. Run SQL Client with `docker compose exec jobmanager /opt/flink/bin/sql-client.sh`, then paste the SQL example after updating connection settings.
5. For air-gapped deployment, transfer this directory **and** Docker images using `docker save` / `docker load`. Images are not bundled.

The JDBC modules may require additional transitive runtime dependencies. Validate `CREATE TABLE` and an INSERT in a connected staging environment before moving offline. Do not add duplicate copies of Flink core libraries. SQL Server sink needs an existing `dbo.events` table with a compatible primary key.
